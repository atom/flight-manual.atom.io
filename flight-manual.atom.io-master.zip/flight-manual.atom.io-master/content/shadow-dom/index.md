---
title: Shadow DOM
---

## Shadow DOM

In Atom `1.13` the Shadow DOM got removed from text editors. Find a guide how to migrate your theme or package in this appendix.
