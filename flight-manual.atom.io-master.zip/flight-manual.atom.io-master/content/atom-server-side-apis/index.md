---
title: Atom server-side APIs
---

## Atom server-side APIs

This appendix covers the the Atom server-side APIs that various parts of Atom consume.

{{#warning}}

**Warning:** These APIs should be considered pre-release and are subject to change.

{{/warning}}
