---
title: FAQ
---
## FAQ

The collection of Frequently Asked Questions about Atom.
