---
title: What does Atom cost?
---
### What does Atom cost?

Since the 6<sup>th</sup> of May, 2014, [Atom has been available for download free of charge for everyone](https://github.blog/2014-05-06-atom-free-and-open-source-for-everyone/). This includes business and enterprise use.
