---
title: What platforms does Atom run on?
---
### What platforms does Atom run on?

Prebuilt versions of Atom are available for OS X 10.10 or later, Windows 7 or later, RedHat Linux, and Ubuntu Linux.

If you would like to build from source on Windows, Linux, or OS X, see the [Atom README](https://github.com/atom/atom/blob/master/README.md#building) for more information.
