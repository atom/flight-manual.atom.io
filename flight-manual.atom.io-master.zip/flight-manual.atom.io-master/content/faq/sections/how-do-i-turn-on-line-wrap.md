---
title: How do I turn on line wrap?
---
### How do I turn on line wrap?

1. Open the Settings View using <kbd>Cmd+,</kbd> on macOS or <kbd>Ctrl+,</kbd> on other platforms
2. Click the “Editor” tab on the left of the settings view
3. Put a check in the “Soft Wrap” setting

For more details about soft wrap, see: https://flight-manual.atom.io/getting-started/sections/atom-basics/#soft-wrap.
