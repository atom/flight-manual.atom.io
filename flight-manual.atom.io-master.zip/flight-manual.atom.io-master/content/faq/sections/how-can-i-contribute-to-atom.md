---
title: How can I contribute to Atom?
---
### How can I contribute to Atom?

You can contribute by [creating a package](https://flight-manual.atom.io/hacking-atom/sections/tools-of-the-trade/) that adds something awesome to Atom!

Also, if you’d like to contribute to the core editor, one of the bundled packages, or one of the libraries that power Atom, just go to [github.com/atom](https://github.com/atom).

You should also read the [contributing guide](https://github.com/atom/atom/blob/master/CONTRIBUTING.md) before getting started.
