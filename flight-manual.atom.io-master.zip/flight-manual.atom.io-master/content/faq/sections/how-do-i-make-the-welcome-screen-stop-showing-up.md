---
title: How do I make the Welcome screen stop showing up?
---
### How do I make the Welcome screen stop showing up?

You can make the Welcome screen stop showing up by unchecking this box in the welcome screen itself:

![Box to uncheck to make the Welcome screen not show next time Atom is launched](../../images/welcome-screen-checkbox.png)
