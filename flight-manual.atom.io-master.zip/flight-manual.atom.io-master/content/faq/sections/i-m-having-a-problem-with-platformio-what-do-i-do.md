---
title: I’m having a problem with PlatformIO! What do I do?
---
### I’m having a problem with PlatformIO! What do I do?

[PlatformIO](http://platformio.org/) is a development environment built on top of Atom but has enough separate customizations that they have their own [message board](https://community.platformio.org/). If your question has to do with PlatformIO specifically, you may have better luck getting your answer there.
