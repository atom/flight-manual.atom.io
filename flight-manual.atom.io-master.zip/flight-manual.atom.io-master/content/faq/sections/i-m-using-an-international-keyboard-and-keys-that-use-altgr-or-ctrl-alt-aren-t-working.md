---
title: I’m using an international keyboard and keys that use AltGr or Ctrl+Alt aren’t working
---
### I’m using an international keyboard and keys that use AltGr or Ctrl+Alt aren’t working

As of Atom v1.12, a fix is available for this. See [the blog post "The Wonderful World of Keyboards"](http://blog.atom.io/2016/10/17/the-wonderful-world-of-keyboards.html) for more information.
