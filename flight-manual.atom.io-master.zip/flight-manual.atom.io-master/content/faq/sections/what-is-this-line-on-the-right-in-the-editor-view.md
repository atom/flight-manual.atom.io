---
title: What is this line on the right in the editor view?
---
### What is this line on the right in the editor view?

![Wrap guide line](../../images/wrap-guide-line.png)

That's the wrap guide. It is a visual indicator of when your lines of code are getting too long. It defaults to the column that your Preferred Line Length is set to.

If you want to turn it off, you can disable the wrap-guide package in the Settings View.
