---
title: I’m having a problem with Julia! What do I do?
---
### I’m having a problem with Julia! What do I do?

[Juno](http://junolab.org/) is a development environment built on top of Atom but has enough separate customizations that they have their own [message board](https://discourse.julialang.org/c/tools/juno). You will probably have better luck asking your question there.
