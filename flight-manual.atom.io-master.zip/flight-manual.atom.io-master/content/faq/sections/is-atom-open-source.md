---
title: Is Atom open source?
---
### Is Atom open source?

Yes, [Atom is licensed under the MIT license.](https://github.com/atom/atom/blob/master/LICENSE.md)
