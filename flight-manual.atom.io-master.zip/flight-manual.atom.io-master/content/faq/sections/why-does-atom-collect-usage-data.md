---
title: Why does Atom collect usage data?
---
### Why does Atom collect usage data?

In the same way that aggregate usage information is important when developing a web application, we've found that it's just as important for desktop applications. By knowing which Atom features are being used the most, and how the editor is performing, we can focus our development efforts in the right place. For details on what data Atom is sending or to learn how to disable metrics gathering, visit https://github.com/atom/metrics.
