---
title: Atom in the cloud?
---
### Atom in the cloud?

The Atom team has no plans to make a cloud- or server-based version of Atom. For discussion of the idea, see the [Atom message board](https://github.com/atom/atom/discussions).
