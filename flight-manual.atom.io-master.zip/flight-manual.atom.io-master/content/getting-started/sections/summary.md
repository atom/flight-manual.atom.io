---
title: Summary
---
### Summary

You should now have a basic understanding of what Atom is and what you want to do with it. You should also have it installed on your system and be able to use it for the most basic text editing operations.

Now you're ready to start digging into the fun stuff.
