---
title: Getting Started
---
## Getting Started

This chapter is about getting started with Atom.
